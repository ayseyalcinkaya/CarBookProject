﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.Application.Feautures.Mediator.Results.FeatureResults
{
    public class GetFeatureQueryResult
    {
        public int FeatureID { get; set; }
        public string Name { get; set; }
    }
}
