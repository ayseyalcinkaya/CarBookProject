﻿using CarBook.Application.Feautures.Mediator.Queries.LocationQueries;
using CarBook.Application.Feautures.Mediator.Queries.PricingQueries;
using CarBook.Application.Feautures.Mediator.Results.LocationResults;
using CarBook.Application.Feautures.Mediator.Results.PricingResults;
using CarBook.Application.Interfaces;
using CarBook.Domain.Entities;
using MediatR;

namespace CarBook.Application.Feautures.Mediator.Handlers.PricingHandlers
{
    public class GetPricingQueryHandler: IRequestHandler<GetPricingQuery, List<GetPricingQueryResult>>
    {
        private readonly IRepository<Pricing> _repository;

        public GetPricingQueryHandler(IRepository<Pricing> repository)
        {
            _repository = repository;
        }

        public async Task<List<GetPricingQueryResult>> Handle(GetPricingQuery request, CancellationToken cancellationToken)
        {
            var values = await _repository.GetAllAsync();
            return values.Select(x => new GetPricingQueryResult
            {
                Name = x.Name,
                PricingID = x.PricingID,
            }).ToList();
        }
    }
}
