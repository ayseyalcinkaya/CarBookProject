﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.Dto.AboutDtos
{
    public class ResultAboutDto
    {

        public int aboutID { get; set; }
        public string title { get; set; }
        public string description { get; set; }
        public string imageURL { get; set; }


    }
}
