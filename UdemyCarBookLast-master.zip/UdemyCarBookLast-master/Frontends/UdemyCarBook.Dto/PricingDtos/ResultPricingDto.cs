﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UdemyCarBook.Dto.PricingDtos
{
    public class ResultPricingDto
    {
        public int PricingID { get; set; }
        public string Name { get; set; }
    }
}
